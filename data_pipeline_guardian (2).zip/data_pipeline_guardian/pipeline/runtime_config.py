PIPELINE_CONFIG = {
    "watermark_minutes": 10  # default
}
